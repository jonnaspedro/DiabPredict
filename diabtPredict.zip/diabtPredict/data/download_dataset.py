import pandas as pd
import os

os.makedirs("data", exist_ok=True)

url = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv"

cols = [
    "Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin",
    "BMI", "DiabetesPedigreeFunction", "Age", "Outcome"
]

df = pd.read_csv(url, names=cols)

df.to_csv("data/diabetes.csv", index=False)

print("Dataset salvo com sucesso em 'data/diabetes.csv'")